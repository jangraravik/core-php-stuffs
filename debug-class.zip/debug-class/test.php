<?php

require_once('debug-class.php');

$variable = array(
    "first"=>"1",
    "second",
    "third"=>array(
        "inner third 1",
        "inner third 2"=>"yeah"),
    "fourth");

new dBug($variable);